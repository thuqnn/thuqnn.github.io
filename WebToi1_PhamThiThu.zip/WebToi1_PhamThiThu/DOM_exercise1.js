function changeLogo() {
    let lgYahoo = document.getElementById("hplogo");
    lgYahoo.src = "https://securitynoob.in/images/honour/yahoo.png";
    lgYahoo.srcset = "https://securitynoob.in/images/honour/yahoo.png";
    return lgYahoo;
}

function changeText() {
    let btnYahoo = document.getElementsByClassName("gNO89b");
    btnYahoo[1].value = "Yahoo!";
    return btnYahoo;
}